//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Resource.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_DIALOG1                     101

#define IDB_BITMAP1                     103
#define IDB_BITMAP2                     104
#define IDB_BITMAP3                     105
#define IDB_BITMAP4                     106
#define IDB_BITMAP5                     107
#define IDB_BITMAP6                     108
#define IDB_BITMAP7                     109
#define IDB_BITMAP8                     110
#define IDB_BITMAP9                     111
#define IDB_BITMAP10                    112

#define IDB_BITMAP11                    113
#define IDB_BITMAP12                    114
#define IDB_BITMAP13                    115
#define IDB_BITMAP14                    116

#define IDC_RADIO1                      1001
#define IDC_RADIO2                      1002
#define IDC_RADIO3                      1003

#define IDC_RADIO4                      1004
#define IDC_RADIO5                      1005
#define IDC_RADIO6                      1006
#define IDC_RADIO7                      1007
#define IDC_RADIO8                      1008

#define IDC_RADIO9                      1009
#define IDC_RADIO10                     1010
#define IDC_RADIO11                     1011
#define IDC_RADIO12                     1012
#define IDC_RADIO13                     1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
